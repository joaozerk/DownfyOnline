# Downfy Online

Interface web com tema inspirado em players musicais e mecanismo [spotDL](https://github.com/spotDL/spotify-downloader), licenciado sob MIT.

Leia **GUIA-HOSPEDAGEM.md** para publicar e administrar o serviço.
