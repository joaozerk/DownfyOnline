"""
Module which contains the web client routes and functions.
"""

import asyncio
from html import escape as html_escape
import uuid
from pathlib import Path
from urllib.parse import urlsplit
import os
import re
from typing import Any, Optional, cast

# from datastar_py.sse import DatastarEvent
from datastar_py.fastapi import ReadSignals
from datastar_py.fastapi import (
    ServerSentEventGenerator as SSE,  # DatastarResponse,; read_signals,
)
from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

from spotdl._version import __version__
from spotdl.download.downloader import AUDIO_PROVIDERS, LYRICS_PROVIDERS
from spotdl.types.song import Song
from spotdl.utils.config import get_spotdl_path
from spotdl.utils.ffmpeg import FFMPEG_FORMATS
from spotdl.utils.search import get_search_results
from spotdl.utils.web import Client, app_state, validate_search_term
from spotdl.web.utils import Signals, datastar_response, handle_signals

__all__ = ["router"]

router = APIRouter()

templates = Jinja2Templates(directory=Path(__file__).parent / "components")


# Public hosting: only accept explicit HTTPS Spotify content links for downloads.
def downfy_spotify_url(url: str) -> bool:
    if not isinstance(url, str) or len(url) > 500:
        return False
    try:
        parsed = urlsplit(url.strip())
        port = parsed.port
    except ValueError:
        return False
    return (
        parsed.scheme == "https"
        and parsed.hostname == "open.spotify.com"
        and port in (None, 443)
        and not parsed.username
        and not parsed.password
        and bool(re.fullmatch(r"/(track|album|playlist|artist)/[a-zA-Z0-9]+/?", parsed.path))
    )



# PATHS


@router.get("/")
async def home(request: Request):
    """
    Handle the home page request.
    """
    return templates.TemplateResponse(
        request=request,
        name="home.html.j2",
        context={"__version__": __version__},
    )


@router.get("/search")
async def search(q: Optional[str], request: Request):
    """
    Handle the search input.
    """
    return templates.TemplateResponse(
        request=request,
        name="search.html.j2",
        context={"__version__": __version__, "search_term": q},
    )


@router.get("/downloads")
async def downloads(request: Request):
    """
    Handle the downloads page request.
    """
    return templates.TemplateResponse(
        request=request,
        name="downloads.html.j2",
        context={
            "__version__": __version__,
        },
    )


# ACTIONS


@router.get("/client/load")
@datastar_response
async def handle_get_client_load(datastar_signals: ReadSignals):
    """
    Handle the loading of the client.
    """
    app_state.logger.info("Loading client...")
    signals = handle_signals(datastar_signals)
    if not re.fullmatch(r"[a-f0-9]{32}", signals.client_id or ""):
        # Generate a new client ID if not provided
        app_state.logger.warning("No client ID provided, generating a new one.")
        signals.client_id = uuid.uuid4().hex
        client = Client(signals.client_id)
    else:
        found_client = Client.get_instance(signals.client_id)
        if found_client is None:
            # Create a new client if not found
            app_state.logger.warning(
                f"Client {signals.client_id} not found, creating new client..."
            )
            signals.client_id = uuid.uuid4().hex
            client = Client(signals.client_id)
        else:
            client = found_client
    await client.connect()

    # First send the client ID and then the home template.
    yield SSE.patch_elements("""<span id="status" class="status-pill"><span class="connection-led"></span><span class="status-text">Conectado</span></span>""")
    # Send the client ID to the client
    yield SSE.patch_signals(
        {
            "client_id": client.client_id,
        }
    )
    try:
        while True:
            yield SSE.patch_elements(f"""<span id="overall-completed-tasks" class="queue-count">
                {len(client.downloader.progress_handler.progress_tracker.songs)}
                </span>""")
            await asyncio.sleep(1)
    finally:
        app_state.logger.info(f"[{signals.client_id}] Unloading client...")
        await client.disconnect()


@router.get("/client/search")
@datastar_response
async def handle_get_client_search(datastar_signals: ReadSignals):
    """
    Handle the search input.
    """
    app_state.logger.info("Loading search...")
    signals = handle_signals(datastar_signals)
    app_state.logger.info(f"[{signals.client_id}] Search term: {signals.search_term}")
    if len(signals.search_term or "") > 500:
        yield SSE.patch_elements('<div id="search-list" class="search-empty-state"><h2>Pesquisa longa demais.</h2><p>Resuma sua busca e tente novamente.</p></div>')
        return
    is_valid_url = downfy_spotify_url(signals.search_term)

    if is_valid_url:
        # Start URL downloads as a background server task before navigation.
        # Spotify links may point to one song or an entire album/playlist/artist.
        app_state.logger.info(
            "[%s] Spotify URL received; opening download queue", signals.client_id
        )
        asyncio.create_task(download_collection(signals.client_id, signals.search_term))
        yield SSE.redirect("/downloads")
        return

    try:
        songs = await asyncio.to_thread(get_search_results, signals.search_term[:160])
        yield SSE.patch_elements(
            templates.get_template("search-list.html.j2").render(songs=songs)
        )
    except Exception as error:
        app_state.logger.error("Search failed: %s", error)
        yield SSE.patch_elements(
            '<div id="search-list" class="search-empty-state">'
            '<div class="empty-visual">!</div>'
            '<h2>Não foi possível concluir a busca</h2>'
            '<p>Verifique sua conexão, tente novamente ou use um link do Spotify.</p>'
            '<button class="secondary-button" onclick="location.reload()">Tentar novamente</button>'
            '</div>'
        )


@router.get("/client/downloads")
@datastar_response
async def handle_get_client_downloads(datastar_signals: ReadSignals):
    """
    Handle the retrieval of client downloads.
    """
    app_state.logger.info("Loading downloads...")
    signals = handle_signals(datastar_signals)
    app_state.logger.info(f"[{signals.client_id}] Downloads requested.")
    client = Client.get_instance(signals.client_id)
    if client is None:
        app_state.logger.warning(
            f"[{signals.client_id}] Client not found, cannot load downloads."
        )
        yield SSE.patch_elements(
            templates.get_template("status-disconnected.html.j2").render()
        )
        return
    while True:
        client_song_downloads = (
            client.downloader.progress_handler.progress_tracker.songs
        )
        yield SSE.patch_elements(
            templates.get_template("download-list.html.j2").render(
                client_song_downloads=client_song_downloads.values()
            )
        )
        await asyncio.sleep(1)


@router.get("/client/settings")
@datastar_response
async def handle_get_client_settings(datastar_signals: ReadSignals):
    """
    Handle the retrieval of client settings.
    """
    signals = handle_signals(datastar_signals)
    client = Client.get_instance(signals.client_id)
    if client is None:
        app_state.logger.warning(
            f"Client {signals.client_id} not found, cannot update settings."
        )
        yield SSE.patch_elements(
            templates.get_template("status-disconnected.html.j2").render()
        )
        return
    app_state.logger.info(f"[{signals.client_id}] Sending client settings...")
    yield SSE.patch_signals(
        {
            "downloader_settings": cast(Any, client.downloader_settings),
        }
    )


@router.post("/client/settings")
@datastar_response
async def handle_post_client_settings(datastar_signals: ReadSignals):
    """
    Handle the update of client settings.
    """
    signals = handle_signals(datastar_signals)
    client = Client.get_instance(signals.client_id)
    error = None
    if client is not None and signals.downloader_settings is not None:
        app_state.logger.info(f"[{signals.client_id}] Updating settings...")
        try:
            client.update_settings(signals.downloader_settings)
        except ValueError as exception:
            error = str(exception)
            app_state.logger.warning(
                f"[{signals.client_id}] Invalid settings, not saved: {error}"
            )

    if client is not None and error is None:
        yield SSE.patch_elements("""
                <div id="settings-status">
                    <div id="settings-is-saved" class="settings-alert">
                        <div>
                            <svg 
                            xmlns="http://www.w3.org/2000/svg" 
                            class="stroke-current flex-shrink-0 h-6 w-6" 
                            fill="none"
                            viewBox="0 0 24 24">
                                <path 
                                stroke-linecap="round" 
                                stroke-linejoin="round" 
                                stroke-width="2"
                                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <span>Alterações salvas!</span>
                        </div>
                    </div>
                </div>
            """)
        yield SSE.patch_signals(
            {
                "downloader_settings": cast(Any, client.downloader_settings),
            }
        )
    else:
        if client is None:
            app_state.logger.warning(
                f"[{signals.client_id}] Client not found, cannot update settings."
            )
            yield SSE.patch_elements(
                templates.get_template("status-disconnected.html.j2").render()
            )
        else:
            # Put the settings shown in the UI back to the saved ones
            yield SSE.patch_signals(
                {
                    "downloader_settings": cast(Any, client.downloader_settings),
                }
            )
        yield SSE.patch_elements("""
                <div id="settings-status">
                    <div id="settings-is-not-saved" class="settings-alert error">
                        <div>
                            <svg 
                            xmlns="http://www.w3.org/2000/svg" 
                            class="stroke-current 
                            flex-shrink-0 h-6 w-6" 
                            fill="none"
                            viewBox="0 0 24 24">
                                <path 
                                stroke-linecap="round" 
                                stroke-linejoin="round" 
                                stroke-width="2"
                d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" 
                            />
                            </svg>
                            <span>Não foi possível salvar as alterações</span>
                        </div>
                    </div>
                </div>
            """)
    #  sleep for 3 seconds then clear the status message
    await asyncio.sleep(3)
    yield SSE.patch_elements("""
            <div id="settings-status">
            </div>
        """)


@router.post("/client/download/")
@datastar_response
async def handle_post_client_download(datastar_signals: ReadSignals):
    """
    Handle the download request from the client.
    """
    signals = handle_signals(datastar_signals)
    async for update in gen_download(signals):
        yield update


# HELPERS


async def gen_download(signals: Signals):
    """
    Generate the download process for the client.
    """
    client = Client.get_instance(signals.client_id)
    if client is None:
        app_state.logger.warning(
            f"Client {signals.client_id} not found, cannot load downloads."
        )
        yield SSE.patch_elements(
            templates.get_template("status-disconnected.html.j2").render()
        )
        return
    app_state.logger.info(
        f"[{signals.client_id}] Download requested: {signals.song_url}"
    )
    if not downfy_spotify_url(signals.song_url):
        yield SSE.patch_elements('<div id="download-error" role="alert">Link do Spotify inválido.</div>')
        return
    safe_id = html_escape(signals.song_url, quote=True)
    yield SSE.patch_elements(f"""
            <button id="download-{safe_id}" class="track-download is-loading" disabled
                    title="Baixando..." aria-label="Baixando...">
                <span class="tiny-spinner"></span><span>Baixando</span>
            </button>
        """)

    # Use the server's output setting, clients can't choose where files go
    if app_state.web_settings.get("web_use_output_dir", False):
        client.downloader.settings["output"] = app_state.downloader_settings["output"]
    else:
        client.downloader.settings["output"] = str(
            (get_spotdl_path() / f"web/sessions/{client.client_id}").absolute()
        )

    try:
        # Fetch song metadata
        song = await asyncio.to_thread(Song.from_url, signals.song_url)
        app_state.logger.info(f"Downloading song: {song}")

        # Download Song
        async with app_state.api.state.download_semaphore:
            _, path = await client.downloader.pool_download(song)
        if path is None:
            app_state.logger.error("Failure downloading %s", song.name)
            yield SSE.patch_elements(f"""
                <button id="download-{safe_id}" class="track-download is-error" disabled
                        title="Não foi possível baixar" aria-label="Falha no download">Falhou</button>
            """)
        else:
            yield SSE.patch_elements(f"""
                <button id="download-{safe_id}" class="track-download is-success" disabled
                        title="Download concluído" aria-label="Download concluído">Concluído</button>
            """)

        # return str(path.absolute())

    except Exception as exception:
        app_state.logger.error("Error downloading! %s", exception)
        yield SSE.patch_elements(f"""
            <button id="download-{safe_id}" class="track-download is-error" disabled
                    title="Falha no download" aria-label="Falha no download">Falhou</button>
        """)




async def download_collection(client_id: str, spotify_url: str):
    """Resolve a track, album, artist or playlist URL and queue its songs."""
    from spotdl.web.api import songs_from_url

    client = Client.get_instance(client_id)
    if client is None:
        app_state.logger.error("[%s] Client unavailable for URL download", client_id)
        return
    if app_state.web_settings.get("web_use_output_dir", False):
        client.downloader.settings["output"] = app_state.downloader_settings["output"]
    else:
        client.downloader.settings["output"] = str(
            (get_spotdl_path() / f"web/sessions/{client.client_id}").absolute()
        )
    if not downfy_spotify_url(spotify_url):
        app_state.logger.warning("Invalid Spotify link in collection")
        return
    try:
        songs = await asyncio.to_thread(songs_from_url, spotify_url)
    except Exception as error:
        app_state.logger.error("[%s] Failed to resolve Spotify link: %s", client_id, error)
        return

    app_state.logger.info("[%s] Queued %d songs", client_id, len(songs))
    maximum = int(os.getenv("DOWNFY_MAX_COLLECTION", "40"))
    if len(songs) > maximum:
        app_state.logger.info("Collection limited to %d tracks", maximum)
    for song in songs[:maximum]:
        try:
            async with app_state.api.state.download_semaphore:
                _, path = await client.downloader.pool_download(song)
            if path is None:
                app_state.logger.error("[%s] Could not download: %s", client_id, song.name)
        except Exception as error:
            app_state.logger.error("[%s] Song download failed: %s", client_id, error)


# COMPONENTS


@router.get("/client/component/settings-content")
@datastar_response
async def handle_get_client_component_settings(datastar_signals: ReadSignals):
    """
    Handle the request for the client settings component.
    """
    signals = handle_signals(datastar_signals)
    client = Client.get_instance(signals.client_id)
    if client is None:
        app_state.logger.warning(
            f"Client {signals.client_id} not found, cannot update settings."
        )
        yield SSE.patch_elements(
            templates.get_template("status-disconnected.html.j2").render()
        )
        return
    app_state.logger.info(f"[{signals.client_id}] Loading settings view...")
    # clear state
    yield SSE.patch_elements("""<div id="component-settings-content"></div>""")
    # render the settings content
    yield SSE.patch_elements(
        templates.get_template("settings-content.html.j2").render(
            downloader_settings=client.downloader_settings,
            AUDIO_PROVIDERS=AUDIO_PROVIDERS,
            LYRICS_PROVIDERS=LYRICS_PROVIDERS,
            FORMATS=FFMPEG_FORMATS.keys(),
        )
    )
    # spotify_client = SpotifyClient()
    # print(f"{spotify_client = }")
    yield SSE.patch_signals(
        {
            "downloader_settings": cast(Any, client.downloader_settings),
            # "spotify_settings": {
            #     "client_id": spotify_client.credential_manager.client_id
            # },
        }
    )


@router.get("/client/component/search-input-rotating-placeholder")
@datastar_response
async def handle_client_component_search_input_rotating_placeholder():
    """
    Handle the search input rotating placeholder component.
    """
    app_state.logger.info("Loading rotating-placeholder...")
    placeholder_items = [
        "All Eyes On Me - Bo Burnham",
        "https://open.spotify.com/track/4vfN00PlILRXy5dcXHQE9M?si=e4d9e7c044dd4a8f",
        "Lil Wayne",
        "Drive - Miley Cyrus",
        "Sofia - TMG",
        "Lightning Crashes - Live",
    ]
    index = 0
    while True:
        t = templates.get_template("search-input-rotating-placeholder.html.j2").render(
            placeholder_item=placeholder_items[index]
        )
        yield SSE.patch_elements(t)
        await asyncio.sleep(5)
        index += 1
        if index >= len(placeholder_items):
            index = 0
