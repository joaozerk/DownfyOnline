(function () {
  'use strict';
  window.studioSubmitSearch = function (event) {
    if (event) event.preventDefault();
    const field = document.getElementById('main-search-input');
    if (!field) return;
    const value = field.value.trim();
    if (!value) { field.focus(); return; }
    window.location.href = '/search?q=' + encodeURIComponent(value);
  };
  window.studioFocusSearch = function () {
    const field = document.getElementById('main-search-input');
    if (field) { field.focus(); field.select(); }
    if (window.innerWidth <= 820) document.getElementById('sidebar')?.classList.remove('open');
  };
  window.studioToggleMenu = function () { document.getElementById('sidebar')?.classList.toggle('open'); };
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); window.studioFocusSearch(); }
    if (e.key === 'Escape') document.getElementById('sidebar')?.classList.remove('open');
  });
  document.addEventListener('click', function(e) {
    if (window.innerWidth <= 820 && !e.target.closest('.sidebar') && !e.target.closest('.mobile-menu')) document.getElementById('sidebar')?.classList.remove('open');
  });
  window.studioToast = function (message) {
    const el = document.getElementById('studio-toast'); if (!el) return;
    el.textContent = message; el.classList.add('visible');
    clearTimeout(el._tid); el._tid = setTimeout(() => el.classList.remove('visible'), 3500);
  };
})();
