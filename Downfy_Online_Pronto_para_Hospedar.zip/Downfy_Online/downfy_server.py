"""Downfy Web: one-worker FastAPI deployment of the spotDL Studio interface.

Run: python downfy_server.py
Environment variables: PORT, DOWNFY_PASSWORD, DOWNFY_USERNAME,
DOWNFY_SESSION_TTL_HOURS, DOWNFY_MAX_COLLECTION, DOWNFY_MAX_DOWNLOADS.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import secrets
import shutil
import time
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from spotdl._version import __version__
from spotdl.types.options import DownloaderOptions
from spotdl.utils.config import DOWNLOADER_OPTIONS, SPOTIFY_OPTIONS, WEB_OPTIONS, get_spotdl_path
from spotdl.utils.web import app_state, fix_mime_types
from spotdl.utils.spotify import SpotifyClient
from spotdl.web import api, routes

logger = logging.getLogger("downfy")
HOME = Path(get_spotdl_path())
SESSION_PATH = HOME / "web" / "sessions"
SESSION_PATH.mkdir(parents=True, exist_ok=True)
AUTH_PASSWORD = os.environ.get("DOWNFY_PASSWORD", "")
AUTH_USERNAME = os.environ.get("DOWNFY_USERNAME", "downfy")
MAX_DOWNLOADS = max(1, min(int(os.environ.get("DOWNFY_MAX_DOWNLOADS", "2")), 6))
SESSION_TTL_SECONDS = max(1, int(os.environ.get("DOWNFY_SESSION_TTL_HOURS", "2"))) * 3600

# The in-memory queue and per-browser sessions require exactly one web worker.
async def expire_old_files() -> None:
    while True:
        await asyncio.sleep(900)
        cutoff = time.time() - SESSION_TTL_SECONDS
        # Only remove files for disconnected clients, never ongoing downloads.
        for directory in SESSION_PATH.iterdir():
            try:
                if not directory.is_dir() or directory.is_symlink():
                    continue
                if directory.name in app_state.clients:
                    continue
                files = list(directory.rglob("*"))
                newest = max((p.stat().st_mtime for p in files if p.is_file()), default=directory.stat().st_mtime)
                if newest < cutoff:
                    shutil.rmtree(directory)
            except (OSError, ValueError):
                logger.exception("Unable to clean up expired session")

@asynccontextmanager
async def lifespan(application: FastAPI):
    fix_mime_types()
    app_state.loop = asyncio.get_running_loop()
    SpotifyClient.init(**{**SPOTIFY_OPTIONS, "headless": True})
    app_state.logger = logging.getLogger("uvicorn.error")
    application.state.download_semaphore = asyncio.Semaphore(MAX_DOWNLOADS)
    cleaner = asyncio.create_task(expire_old_files())
    logger.info("Downfy online started (spotDL %s, simultaneous downloads=%s)", __version__, MAX_DOWNLOADS)
    try:
        yield
    finally:
        cleaner.cancel()
        try:
            await cleaner
        except asyncio.CancelledError:
            pass

app = FastAPI(title="Downfy", version="1.0.0", lifespan=lifespan)
app_state.api = app
app_state.web_settings = {**WEB_OPTIONS, "web_use_output_dir": False, "keep_alive": True, "keep_sessions": False}
app_state.downloader_settings = DownloaderOptions(**{
    **DOWNLOADER_OPTIONS,
    "threads": 2,
    "simple_tui": True,
    "log_level": "INFO",
    "format": "mp3",
    "output": "{artists} - {title}.{output-ext}",
})

# Basic Auth is optional but highly recommended for private deployments.
# Health checks remain public so hosters can verify deployment status.
@app.middleware("http")
async def access_control(request: Request, call_next):
    if request.url.path == "/health":
        return await call_next(request)
    if AUTH_PASSWORD:
        value = request.headers.get("authorization", "")
        try:
            kind, encoded = value.split(" ", 1)
            raw = base64.b64decode(encoded, validate=True).decode("utf-8")
            supplied_user, supplied_pass = raw.split(":", 1)
            authorized = (kind.lower() == "basic"
                          and secrets.compare_digest(supplied_user, AUTH_USERNAME)
                          and secrets.compare_digest(supplied_pass, AUTH_PASSWORD))
        except (ValueError, UnicodeDecodeError):
            authorized = False
        if not authorized:
            return Response("Acesso restrito ao Downfy", status_code=401,
                            headers={"WWW-Authenticate": 'Basic realm="Downfy"'})
    # Simple in-process throttle, scoped to expensive actions and one worker.
    if request.url.path in ("/client/download/", "/client/search", "/api/download/url", "/api/songs/search", "/api/url"):
        now = time.monotonic()
        key = (request.client.host if request.client else "anonymous", request.url.path)
        events = app.state.recent_calls.setdefault(key, [])
        events[:] = [ts for ts in events if now - ts < 60]
        limit = 8 if "download" in request.url.path else 20
        if len(events) >= limit:
            return JSONResponse({"detail":"Muitas solicitações. Aguarde um minuto."}, status_code=429)
        events.append(now)
        if len(app.state.recent_calls) > 3000:
            app.state.recent_calls.clear()
    return await call_next(request)

app.state.recent_calls = {}
app.include_router(api.router)
app.include_router(routes.router)

@app.get("/health")
async def health():
    return {"ok": True, "service": "Downfy", "spotdl_version": __version__}

STATIC_DIR = Path(__file__).resolve().parent / "spotdl" / "web" / "static" / "assets"
app.mount("/assets", StaticFiles(directory=STATIC_DIR), name="assets")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "10000"))
    uvicorn.run("downfy_server:app", host="0.0.0.0", port=port,
                workers=1, log_level="info", proxy_headers=True)
