# Downfy — publicar online

Esta versão roda em **um único serviço Docker**, incluindo interface e backend. Não é um site estático: **GitHub Pages, Netlify estático e Vercel estático não executam o mecanismo do spotDL**.

## Railway (recomendado)

1. Descompacte este pacote e coloque seu conteúdo **na raiz** de um repositório GitHub.
2. Acesse https://railway.com/new e escolha **Deploy from GitHub repo**.
3. Selecione o repositório. A Railway encontrará o `Dockerfile` e lerá o `railway.toml`.
4. Em **Variables**, configure `DOWNFY_PASSWORD` com uma senha forte (recomendado), e se quiser `DOWNFY_USERNAME` (padrão: `downfy`).
5. Em **Settings → Networking**, escolha **Generate Domain**. O domínio gerado será seu link público de acesso.
6. Abra o domínio no navegador. Se houver senha configurada, o navegador pedirá usuário/senha antes de carregar a interface.

**Alternativa sem GitHub:** instalar a Railway CLI, fazer login, `railway init` e `railway up` dentro da pasta. Gere o domínio público no painel da Railway.

## Render

1. Publique a pasta como repositório GitHub.
2. Acesse https://dashboard.render.com/ e crie **New → Web Service**, conectado ao repositório, com `Docker` como ambiente.
3. Configure `DOWNFY_PASSWORD` em Environment. O `render.yaml` também permite um Blueprint com plano Starter.
4. Aguarde o deploy e use o endereço `*.onrender.com` fornecido pela plataforma.

## Executar no computador para testar

Com Docker Desktop instalado, na pasta:

```bash
docker compose up --build
```

Acesse http://localhost:10000. Se usar `.env` (copie `.env.example`), o navegador pedirá senha.

## Como funciona

- Busca músicas com os serviços usados pelo spotDL.
- Links do Spotify (música/álbum/playlist/artista) iniciam o processamento no servidor.
- **Os arquivos NÃO chegam automaticamente ao dispositivo**: depois que concluírem, vá até **Downloads → Salvar**.
- O servidor salva os arquivos por sessão e os exclui depois de um período; normalmente **2 horas após ficarem inativos**. Provedores com disco temporário também apagam os arquivos ao reiniciar.
- Um único worker é obrigatório porque as filas estão em memória. Não há banco de dados nem distribuição de tarefas entre servidores.
- `DOWNFY_MAX_DOWNLOADS=2` limita downloads simultâneos no servidor. `DOWNFY_MAX_COLLECTION=40` limita faixas por link de coleção.
- Se o servidor ou a plataforma reiniciar, o trabalho em andamento será perdido.

## Segurança e uso permitido

- A instância pública pode gastar CPU/banda rapidamente. Habilite a senha e use limites da plataforma. A aplicação tem proteção básica contra solicitações em excesso, mas **não é adequada para lançamento público amplo sem autenticação real, rate limits distribuídos, filas persistentes, supervisão e termos de uso**.
- Hospede apenas onde ferramentas de download de áudio forem permitidas. Baixe/distribua somente conteúdo para o qual você tenha autorização.
- Downfy não é afiliado ao Spotify e não extrai diretamente áudios do Spotify: o motor spotDL usa metadados e outras fontes compatíveis.
- Por exigência técnica de hospedagem, a conversão usa FFmpeg instalado no contêiner. Alguns provedores de áudio podem bloquear acessos a partir de servidores em nuvem ou mudar suas APIs, causando falha nos downloads.
- Para produção com múltiplos usuários, é necessário refatorar a fila em tarefas persistentes (por exemplo Redis + workers), implementar autenticação e isolamento por usuário, políticas de armazenamento e métricas.

## Variáveis

| Variável | Padrão | Efeito |
| --- | --- | --- |
| `PORT` | `10000` | Porta HTTP (Railway/Render fornecem automaticamente). |
| `DOWNFY_PASSWORD` | vazio | Proteção HTTP Basic (vazio = acesso aberto). |
| `DOWNFY_USERNAME` | `downfy` | Usuário da proteção HTTP Basic. |
| `DOWNFY_MAX_DOWNLOADS` | `2` | Processamentos simultâneos (1–6). |
| `DOWNFY_MAX_COLLECTION` | `40` | Máximo de faixas por link de coleção. |
| `DOWNFY_SESSION_TTL_HOURS` | `2` | Prazo mínimo de retenção de arquivos inativos. |

## Aviso de licenciamento

O mecanismo usado é uma adaptação do projeto de código aberto spotDL (MIT), que mantém sua licença original em `LICENSE`. A marca **Downfy** é uma personalização da interface. Este pacote não contém músicas.
